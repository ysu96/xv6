#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "spinlock.h"
#include "slab.h"
#include <stdbool.h>

struct {
	struct spinlock lock;
	struct slab slab[NSLAB]; 
} stable;

int nslab_size(int num){
	int size=1;
	int i=0;
	for(i=0; i<num; i++){
		size <<= 1;
	}
	return size;
}

void slabinit(){
	//reset stable
	struct slab *s;
	acquire(&stable.lock);

	int i=3;
	for(s=stable.slab; s<&stable.slab[NSLAB]; s++){
		s->size=nslab_size(i++);
		s->num_pages=1;
		s->num_free_objects=(MAX_OBJECTS_PER_PAGE/s->size);
		s->num_used_objects=0;
		s->num_objects_per_page=(MAX_OBJECTS_PER_PAGE/s->size);
		s->bitmap=kalloc(); 
		s->page[(s->num_pages-1)]=kalloc(); 
	}
	release(&stable.lock);
}

char *kmalloc(int size){
	char *addr = 0;
	struct slab *s;

	int sidx=0;
	int pidx=0;
	int offset;

	int val = size >> 3;
	int sn; //slot number
	
	int i,j;

	// boundary check  
	if(size > 2048){
		return 0x00;
	}
	
	// find the smallest power of two greater than size 
	while (val > 0){
		val >>=1;
		sidx++;
	}

	s = &stable.slab[sidx];
	acquire(&stable.lock);

	// find free slot
	for(i = 0; i < BYTES_PER_PAGE; i++){
		char mask = 0x1;
		char bitvec = s->bitmap[i];
		for(j=0; j< BITS_PER_CHAR; j++){
			if(!(bitvec & mask)){
				s->bitmap[i] |= mask;
				goto found;
			}
			mask <<=1;
		}
	}
	release(&stable.lock);
	return 0x00;

found:
	if(s->num_free_objects == 0){
		s->num_pages++;
		s->num_free_objects += s->num_objects_per_page;
		s->page[(s->num_pages-1)] = kalloc();
	}
	
	// calculate slot number 
	sn = i * BITS_PER_CHAR + j;
	pidx = sn / s->num_objects_per_page;
	offset = sn % s->num_objects_per_page;

	addr = s->page[pidx] + offset * s->size; 
	
	s->num_used_objects++;
	s->num_free_objects--;
	
	release(&stable.lock);

	return addr;
}

void kmfree(char *addr, int size)
{
	struct slab *s;
  int sidx=0;
  int pidx=0;
	int i, j;    
  int val = size >> 3;


	// find the smallest power of two greater than size 
   while (val >0){
      val >>=1;
      sidx++;
	}   
  
	s = &stable.slab[sidx];
	
	acquire(&stable.lock);
	
	//find slot
	for(i = 0; i < BYTES_PER_PAGE; i++){
		char mask = 0x0;

		for(j=0; j< BITS_PER_CHAR; j++){
			for(pidx=0; pidx<s->num_pages; pidx++){
					if(addr == s->page[pidx] + s->size + i*BITS_PER_CHAR +j){
						s->bitmap[i] &= mask;
						goto found;
					}
					if(addr ==s->page[pidx]){
						s->bitmap[0] &=mask;
						goto found;
					}
			}
		}   
	}   

	release(&stable.lock);
	return;

found:
	s->num_used_objects--;
	if(s->num_used_objects < (s->num_pages-1) * s->num_objects_per_page){
		kfree(s->page[(s->num_pages-1)]);
		s->num_pages--;
		s->num_free_objects -= s->num_objects_per_page;
	}
	s->num_free_objects++;
	release(&stable.lock);
	return;

}

void slabdump(){
	cprintf("__slabdump__\n");

	struct slab *s;

	cprintf("size\tnum_pages\tused_objects\tfree_objects\n");

	for(s = stable.slab; s < &stable.slab[NSLAB]; s++){
		cprintf("%d\t%d\t\t%d\t\t%d\n", 
			s->size, s->num_pages, s->num_used_objects, s->num_free_objects);
	}
}
