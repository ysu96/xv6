#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
int main(){
    int p[2];
    char* argv[2];
    argv[0] = "wc";
    argv[1] = 0;
    int status;
    pipe(p); //p[0] : readfd, p[1] : writefd
    if(fork() == 0){ //child
        close(0); //fd 0번칸 비우기
        dup(p[0]); //0번칸도 p[0] 가리키게함
        close(p[0]); 
        close(p[1]);
        execve("/usr/bin/wc",argv,NULL);
    } else{
        close(p[0]);
        write(p[1],"hello world\n",12);
        close(p[1]);
        wait(&status);
    }
}