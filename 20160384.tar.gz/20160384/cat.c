#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
void cat(int fd){
    int n;
    char* buf = malloc(sizeof(char)*50);
    while((n=read(fd,buf,sizeof(buf)))>0){
        if(write(1,buf,n)!=n){ 
            printf("cat: write error\n");
            return;
        }
    }
    if(n<0){
        printf("cat: read error\n");
        return;
    }
    free(buf);
    printf("\n");
}

int main(int argc, char** argv){
    int fd, i;
    if(argc<=1){
        //cat(0);
        exit(1);
    }

    for(i=1;i<argc;i++){
        if((fd = open(argv[i],0))<0){ //open() : File descriptor 인덱스 리턴
            dprintf(1,"cat: cannot open %s\n",argv[i]);
            exit(1);
        }

        cat(fd);
        close(fd);
    }
    exit(1);
}